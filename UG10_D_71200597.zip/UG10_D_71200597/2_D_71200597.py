# input('Masukkan nama pemain pertama: ')
# input('Masukkan nama pemain kedua: ')
# input('Masukkan nama pemain ketiga: ')
# input('Masukkan jumlah kartu pemain pertama: ')
# input('Masukkan jumlah kartu pemain kedua: ')
# input('Masukkan jumlah kartu pemain ketiga: ')

p1 = input('Masukkan nama pemain pertama:')
p2 = input('Masukkan nama pemain kedua:')
p3 = input('Masukkan nama pemain ketiga:')
kartu_p1 = int(input('Masukkan jumlah kartu pemain pertama:'))
kartu_p2 = int(input('Masukkan jumlah kartu pemain kedua:'))
kartu_p3= int(input('Masukkan jumlah kartu pemain ketiga:'))

if kartu_p1 > 21 or kartu_p2 > 21 or kartu_p3 > 21:
    print('Jumlah kartu yang dimiliki melebihi batas')
else:
    if kartu_p1 > kartu_p2 and kartu_p1 > kartu_p3:
        print(p1,'menang dengan jumlah kartu sebanyak',kartu_p1)
    elif kartu_p2 > kartu_p1 and kartu_p2 > kartu_p3:
        print(p2,'menang dengan jumlah kartu sebanyak',kartu_p2)
    elif kartu_p3 > kartu_p1 and kartu_p3 > kartu_p2:
        print(p3,'menang dengan jumlah kartu sebanyak',kartu_p3)
