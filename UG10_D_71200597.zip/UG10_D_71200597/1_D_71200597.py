print("Selamat datang di kalkulator sederhana")
print("Ketik 1 untuk menghitung penjumlahan")
print("Ketik 2 untuk menghitung pengurangan")
print("Ketik 3 untuk menghitung perkalian")
print("Ketik 4 untuk menghitung pembagian")
print("Ketik 5 untuk menghitung sisa hasil bagi(modulus)")
print("Ketik 6 untuk menghitung pangkat")

pilihan = int(input("Masukkan pilihan anda: "))
angka1 = int(input("Masukkan bilangan pertama: "))
angka2 = int(input("Masukkan bilangan kedua: "))
if pilihan == 1:
    print(f"Hasil dari {angka1} dijumlahkan dengan {angka2} adalah {angka1 + angka2}")
elif pilihan == 2: 
    print(f"Hasil dari {angka1} dikurangkan dengan {angka2} adalah {angka1 - angka2}")
elif pilihan == 3:
    print(f"Hasil dari {angka1} dikalikan dengan {angka2} adalah {angka1 * angka2}")
elif pilihan == 4:
    print(f"Hasil dari {angka1} dibagi dengan {angka2} adalah {angka1 / angka2}")
elif pilihan == 5:
    print(f"Hasil dari {angka1} dimodulus dengan {angka2} adalah {angka1 % angka2}")
elif pilihan == 6:
    print(f"Hasil dari {angka1} dipangkatkan dengan {angka2} adalah {angka1 ** angka2}")