print('Hello asdos') 
print('Berikut ini merupakan program pengecekan tahun kabisat.')
#Inputan Angka
angka = int(input("Masukkan Tahun : "))
#Pengecekan Angka
if(angka % 4 == 0):
    print(angka, "merupakan Tahun kabisat.")
else:
    print(angka, "bukan merupakan tahun kabisat.")